import os

def hello():
    print("Hi {0}".format(os.getlogin()))
    print("Thank you for using my python library")  